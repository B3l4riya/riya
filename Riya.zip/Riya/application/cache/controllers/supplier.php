<?php

class supplier extends CI_model{
    pubic fuction tampil_data()
    {
      return $this->db->get('tb_supplier');
    }
}