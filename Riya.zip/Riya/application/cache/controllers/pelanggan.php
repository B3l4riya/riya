<?php

class pelanggan extends CI_control{
    public funtion index()
  {
    $data['pelanggan'] = $this->pelanggan->tampil_data()->result();
    $this->load->view('templates/footer');
    $this->load->view('templates/sidebar');
    $this->load->view('pelanggan',$data);
    $this->load->view('templates/footer');

  }
  }
